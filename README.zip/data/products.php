<?php
// Products data file - contains all product information
// This file will be included in other pages to access product data

$products = [];

// Marble Products
$products = array_merge($products, [
    [
        'id' => 'marble-carrara-white',
        'name' => 'Carrara White Мермер',
        'category' => 'marble',
        'description' => 'Класичен бел мермер од Италија со елегантни сиви вени.',
        'long_description' => 'Carrara White е премиум мермер од Италија, познат по својата чиста бела боја и фини сиви вени. Одличен за луксузни ентериери.',
        'features' => ['Елегантен изглед', 'Висока квалитет', 'Луксузен материјал'],
        'applications' => ['Подови', 'Облоги', 'Кујнски работни плочи', 'Бањски шкафчиња'],
        'images' => ['marbel-types/viscon-white.jpg'],
        'main_image' => 'marbel-types/viscon-white.jpg',
        'availability' => 'По нарачка',
        'thickness' => '2cm, 3cm',
        'finish' => 'Полиран, Матиран'
    ],
    [
        'id' => 'marble-statuario',
        'name' => 'Statuario Мермер',
        'category' => 'marble',
        'description' => 'Премиум бел мермер со златни вени од Италија.',
        'long_description' => 'Statuario е еден од најлуксузните мермери од Италија, со карактеристични златни вени на бела основа.',
        'features' => ['Луксузен изглед', 'Златни вени', 'Премиум класа'],
        'applications' => ['Подови', 'Облоги', 'Скали', 'Декоративни површини'],
        'images' => ['marbel-types/Blue-Pearl.jpg'],
        'main_image' => 'marbel-types/Blue-Pearl.jpg',
        'availability' => 'По нарачка',
        'thickness' => '2cm, 3cm',
        'finish' => 'Полиран'
    ],
    [
        'id' => 'marble-calacatta-gold',
        'name' => 'Calacatta Gold Мермер',
        'category' => 'marble',
        'description' => 'Бел мермер со златни вени од Италија.',
        'long_description' => 'Calacatta Gold е мермер со интензивни златни вени на бела основа. Впечатлив за луксузни проекти.',
        'features' => ['Златни вени', 'Впечатлив изглед', 'Луксузен материјал'],
        'applications' => ['Кујнски работни плочи', 'Бањски шкафчиња', 'Подови'],
        'images' => ['marbel-types/star-galaxy.jpeg'],
        'main_image' => 'marbel-types/star-galaxy.jpeg',
        'availability' => 'По нарачка',
        'thickness' => '2cm, 3cm',
        'finish' => 'Полиран'
    ],
    [
        'id' => 'marble-emperador-dark',
        'name' => 'Emperador Dark Мермер',
        'category' => 'marble',
        'description' => 'Темно кафеав мермер со бели вени од Шпанија.',
        'long_description' => 'Emperador Dark е мермер со богата кафеава боја и контрастни бели вени. Одличен за модерни ентериери.',
        'features' => ['Темна боја', 'Контрастни вени', 'Модерен изглед'],
        'applications' => ['Подови', 'Облоги', 'Кујнски работни плочи'],
        'images' => ['marbel-types/Multicolor.jpeg'],
        'main_image' => 'marbel-types/Multicolor.jpeg',
        'availability' => 'По нарачка',
        'thickness' => '2cm, 3cm',
        'finish' => 'Полиран, Матиран'
    ],
    [
        'id' => 'marble-botticino',
        'name' => 'Botticino Мермер',
        'category' => 'marble',
        'description' => 'Беж мермер со топла нијанса од Италија.',
        'long_description' => 'Botticino е мермер со топла беж нијанса и фини вени. Создава топла и пријатна атмосфера.',
        'features' => ['Топла нијанса', 'Пријатна атмосфера', 'Лесно комбинирање'],
        'applications' => ['Подови', 'Облоги', 'Скали', 'Фасади'],
        'images' => ['marbel-types/Crema-Julia.jpeg'],
        'main_image' => 'marbel-types/Crema-Julia.jpeg',
        'availability' => 'По нарачка',
        'thickness' => '2cm, 3cm',
        'finish' => 'Полиран, Матиран'
    ],
    [
        'id' => 'marble-rosso-levanto',
        'name' => 'Rosso Levanto Мермер',
        'category' => 'marble',
        'description' => 'Црвен мермер со бели вени од Италија.',
        'long_description' => 'Rosso Levanto е мермер со интензивна црвена боја и контрастни бели вени. Впечатлив за специјални проекти.',
        'features' => ['Интензивна боја', 'Контрастни вени', 'Впечатлив изглед'],
        'applications' => ['Декоративни површини', 'Облоги', 'Скали'],
        'images' => ['marbel-types/Koliqi.jpg'],
        'main_image' => 'marbel-types/Koliqi.jpg',
        'availability' => 'По нарачка',
        'thickness' => '2cm, 3cm',
        'finish' => 'Полиран'
    ],
]);

// Additional stone types (granite) placeholders
$products = array_merge($products, [
    [
        'id' => 'granite-rosa-beta',
        'name' => 'Rosa Beta Гранит',
        'category' => 'granite',
        'description' => 'Класичен сив гранит од Сардинија со униформна текстура.',
        'long_description' => 'Rosa Beta е гранит од Сардинија, Италија, познат по својата униформна сиво-розева текстура со ситни зрна. Одличен за екстериер и интериер поради високата издржливост.',
        'features' => ['Висока издржливост', 'Отпорност на временски влијанија', 'Ниска порозност'],
        'applications' => ['Подови', 'Фасади', 'Скали', 'Кујнски работни плочи'],
        'images' => ['marbel-types/rosobeta.jpg'],
        'main_image' => 'marbel-types/rosobeta.jpg',
        'availability' => 'Достапен',
        'thickness' => '2cm, 3cm',
        'finish' => 'Полиран, Матиран'
    ],
    [
        'id' => 'granite-g664-bainbrook-brown',
        'name' => 'G664 (Bainbrook Brown) Гранит',
        'category' => 'granite',
        'description' => 'Кафеав гранит од Кина со равномерна зрнеста структура.',
        'long_description' => 'G664, познат и како Bainbrook Brown, е кинески гранит со топла кафеава нијанса и униформна текстура. Често се користи за плочи и степеници.',
        'features' => ['Униформен изглед', 'Добра ценовна класа', 'Лесно одржување'],
        'applications' => ['Кујнски рабови', 'Подови', 'Степеници'],
        'images' => ['marbel-types/images.jpeg'],
        'main_image' => 'marbel-types/images.jpeg',
        'availability' => 'Достапен',
        'thickness' => '2cm, 3cm',
        'finish' => 'Полиран, Матиран'
    ],
    [
        'id' => 'granite-balmoral-red',
        'name' => 'Balmoral Red Гранит',
        'category' => 'granite',
        'description' => 'Длабоко црвен гранит од Финска со висока густина.',
        'long_description' => 'Balmoral Red е фински гранит, познат по својата богата црвена боја и долготрајна стабилност. Идеален за високо-фреквентни површини.',
        'features' => ['Висока густина', 'Естетски впечатлив', 'Одличен за екстериер'],
        'applications' => ['Фасади', 'Споменици', 'Подови'],
        'images' => ['marbel-types/unnamed.jpg'],
        'main_image' => 'marbel-types/unnamed.jpg',
        'availability' => 'Достапен',
        'thickness' => '2cm, 3cm',
        'finish' => 'Полиран, Матиран'
    ],
    [
        'id' => 'granite-g603',
        'name' => 'G603 Гранит',
        'category' => 'granite',
        'description' => 'Светло сив кинески гранит (Bianco Crystal) со униформна зрнестост.',
        'long_description' => 'G603 е светло сив гранит од Кина, познат под името Bianco Crystal. Одличен избор за јавни и приватни проекти.',
        'features' => ['Униформна боја', 'Отпорен на абење', 'Прифатлива цена'],
        'applications' => ['Плочки', 'Кантари', 'Надворешни површини'],
        'images' => ['marbel-types/g603-.jpeg'],
        'main_image' => 'marbel-types/g603-.jpeg',
        'availability' => 'Достапен',
        'thickness' => '2cm, 3cm',
        'finish' => 'Полиран, Жбрусен'
    ],
    [
        'id' => 'granite-viscount-white',
        'name' => 'Viscon White Гранит',
        'category' => 'granite',
        'description' => 'Индиски сиво-бел гранит со динамични вени.',
        'long_description' => 'Viscon (Viscount) White е индиски гранит со контрастни сиви вени на бела основа. Популарен за модерни кујни и бањи.',
        'features' => ['Модерен изглед', 'Добра отпорност', 'Лесно комбинирање'],
        'applications' => ['Кујнски рабови', 'Облоги', 'Подови'],
        'images' => ['marbel-types/viscon-white.jpg'],
        'main_image' => 'marbel-types/viscon-white.jpg',
        'availability' => 'Достапен',
        'thickness' => '2cm, 3cm',
        'finish' => 'Полиран, Матиран'
    ],
    [
        'id' => 'granite-vizag-blue',
        'name' => 'Vizag Blue Гранит',
        'category' => 'granite',
        'description' => 'Синкаво-сив индиски гранит со перлист ефект.',
        'long_description' => 'Vizag Blue е индиски гранит со синкаво-сиви тонови и флеки што рефлектираат светлина. Дава елегантен изглед.',
        'features' => ['Елегантен сјај', 'Отпорност на гребење', 'Ниско одржување'],
        'applications' => ['Кујни', 'Бањи', 'Декоративни површини'],
        'images' => ['marbel-types/Vizag-vblue.jpeg'],
        'main_image' => 'marbel-types/Vizag-vblue.jpeg',
        'availability' => 'Достапен',
        'thickness' => '2cm, 3cm',
        'finish' => 'Полиран, Матиран'
    ],
    [
        'id' => 'granite-blue-pearl',
        'name' => 'Blue Pearl Гранит',
        'category' => 'granite',
        'description' => 'Норвешки гранит со сини перла ефекти и силен металичен сјај.',
        'long_description' => 'Blue Pearl е премиум норвешки гранит со карактеристични сини перла-флеки. Одличен за луксузни ентериери.',
        'features' => ['Впечатлив изглед', 'Висока издржливост', 'Премиум класа'],
        'applications' => ['Работни плочи', 'Шанкови', 'Интериерни облоги'],
        'images' => ['marbel-types/Blue-Pearl.jpg'],
        'main_image' => 'marbel-types/Blue-Pearl.jpg',
        'availability' => 'Достапен',
        'thickness' => '2cm, 3cm',
        'finish' => 'Полиран'
    ],
    [
        'id' => 'granite-multicolor-red',
        'name' => 'Multicolor Гранит',
        'category' => 'granite',
        'description' => 'Индиски мултиколор гранит со топли црвени и кафеави нијанси.',
        'long_description' => 'Multicolor (често Red Multicolor) е индиски гранит со динамичен микс на црвени и кафеави тонови. Издржлив и впечатлив.',
        'features' => ['Трајност', 'Топли нијанси', 'Визуелна динамика'],
        'applications' => ['Подови', 'Кујнски плочи', 'Надворешни облоги'],
        'images' => ['marbel-types/Multicolor.jpeg'],
        'main_image' => 'marbel-types/Multicolor.jpeg',
        'availability' => 'Достапен',
        'thickness' => '2cm, 3cm',
        'finish' => 'Полиран, Матиран'
    ],
    [
        'id' => 'granite-crema-julia',
        'name' => 'Crema Julia Гранит',
        'category' => 'granite',
        'description' => 'Шпански светло беж гранит со фина структура.',
        'long_description' => 'Crema Julia е гранит од Шпанија, светло беж со фина зрнестост. Се користи и за ентериер и екстериер.',
        'features' => ['Неутрална боја', 'Лесно комбинирање', 'Издржлив'],
        'applications' => ['Подови', 'Фасади', 'Работни плочи'],
        'images' => ['marbel-types/Crema-Julia.jpeg'],
        'main_image' => 'marbel-types/Crema-Julia.jpeg',
        'availability' => 'Достапен',
        'thickness' => '2cm, 3cm',
        'finish' => 'Полиран, Матиран'
    ],
    [
        'id' => 'granite-emerald-pearl',
        'name' => 'Emerald Pearl Гранит',
        'category' => 'granite',
        'description' => 'Норвешки темно зелен гранит со перла ефекти.',
        'long_description' => 'Emerald Pearl е гранит со длабоко зелена основа и перла-ефект. Премиум избор за луксузни површини.',
        'features' => ['Премиум изглед', 'Висока издржливост', 'Елегантен сјај'],
        'applications' => ['Работни плочи', 'Интериерни облоги'],
        'images' => ['marbel-types/Emerald-pearl.jpeg'],
        'main_image' => 'marbel-types/Emerald-pearl.jpeg',
        'availability' => 'Достапен',
        'thickness' => '2cm, 3cm',
        'finish' => 'Полиран'
    ],
    [
        'id' => 'granite-african-red',
        'name' => 'Red Africa Гранит',
        'category' => 'granite',
        'description' => 'Богат црвен гранит од Јужна Африка со висока издржливост.',
        'long_description' => 'Red Africa е гранит со интензивна црвена боја и темни флеки. Одличен за екстериерни апликации.',
        'features' => ['Висока издржливост', 'Интензивна боја'],
        'applications' => ['Споменици', 'Фасади', 'Подови'],
        'images' => ['marbel-types/Koliqi.jpg'],
        'main_image' => 'marbel-types/Koliqi.jpg',
        'availability' => 'Достапен',
        'thickness' => '2cm, 3cm',
        'finish' => 'Полиран, Матиран'
    ],
    [
        'id' => 'granite-zimbabwe-black',
        'name' => 'Zimbabwe Black Гранит',
        'category' => 'granite',
        'description' => 'Финозрнест црн гранит од Зимбабве со униформен изглед.',
        'long_description' => 'Zimbabwe Black е црн гранит со висока густина и елегантен мат сјај. Многу популарен за работни плочи.',
        'features' => ['Униформна црна боја', 'Лесно одржување'],
        'applications' => ['Кујни', 'Бањи', 'Облоги'],
        'images' => ['marbel-types/Zimbabwe.jpg'],
        'main_image' => 'marbel-types/Zimbabwe.jpg',
        'availability' => 'Достапен',
        'thickness' => '2cm, 3cm',
        'finish' => 'Полиран, Матиран'
    ],
    [
        'id' => 'granite-star-galaxy',
        'name' => 'Star Galaxy Гранит',
        'category' => 'granite',
        'description' => 'Црн индиски гранит со златести флеки – ефект на „ѕвездено небо“.',
        'long_description' => 'Star Galaxy од Индија е познат по своите бронзено-златни точки на длабока црна основа. Впечатлив и луксузен.',
        'features' => ['Визуелен ефект', 'Висока издржливост'],
        'applications' => ['Работни плочи', 'Шанкови', 'Интериерни детали'],
        'images' => ['marbel-types/star-galaxy.jpeg'],
        'main_image' => 'marbel-types/star-galaxy.jpeg',
        'availability' => 'Достапен',
        'thickness' => '2cm, 3cm',
        'finish' => 'Полиран'
    ],
    [
        'id' => 'granite-impala',
        'name' => 'Impala Гранит',
        'category' => 'granite',
        'description' => 'Темно сив јужноафрикански гранит со униформен образец.',
        'long_description' => 'Impala (најчесто од RSA) е издржлив гранит со неутрална боја, погоден за разни примени.',
        'features' => ['Неутрален изглед', 'Висока отпорност'],
        'applications' => ['Подови', 'Фасади', 'Кантари'],
        'images' => ['marbel-types/Impala.jpg'],
        'main_image' => 'marbel-types/Impala.jpg',
        'availability' => 'Достапен',
        'thickness' => '2cm, 3cm',
        'finish' => 'Полиран, Матиран'
    ],
    [
        'id' => 'granite-rosa-porrino',
        'name' => 'Rosa Porrino Гранит',
        'category' => 'granite',
        'description' => 'Шпански розев гранит со униформна зрнестост.',
        'long_description' => 'Rosa Porrino (Галиција, Шпанија) е познат по топлата розева нијанса и униформната структура. Одличен за големи површини.',
        'features' => ['Униформен', 'Топол тон'],
        'applications' => ['Подови', 'Фасади', 'Скали'],
        'images' => ['marbel-types/Rosa-porino.jpeg'],
        'main_image' => 'marbel-types/Rosa-porino.jpeg',
        'availability' => 'Достапен',
        'thickness' => '2cm, 3cm',
        'finish' => 'Полиран, Матиран'
    ],
    [
        'id' => 'granite-guna-black',
        'name' => 'Guna Black Гранит',
        'category' => 'granite',
        'description' => 'Длабок црн гранит со фина зрнестост.',
        'long_description' => 'Guna Black е црн гранит со униформна фина структура. Одличен за елегантни, минималистички решенија.',
        'features' => ['Финозрнест', 'Елегантен'],
        'applications' => ['Работни плочи', 'Облоги', 'Подови'],
        'images' => ['marbel-types/Guna-black.avif'],
        'main_image' => 'marbel-types/Guna-black.avif',
        'availability' => 'Достапен',
        'thickness' => '2cm, 3cm',
        'finish' => 'Полиран, Матиран'
    ],
    [
        'id' => 'granite-shanxi-black',
        'name' => 'Shanxi Black Гранит',
        'category' => 'granite',
        'description' => 'Кинески премиум црн гранит со униформен изглед.',
        'long_description' => 'Shanxi Black е познат по својата чиста црна боја и одлична завршна обработка. Високо ценет за луксузни апликации.',
        'features' => ['Премиум црна', 'Униформна структура'],
        'applications' => ['Споменици', 'Работни плочи', 'Интериер'],
        'images' => ['marbel-types/Xhanxi black.jpg'],
        'main_image' => 'marbel-types/Xhanxi black.jpg',
        'availability' => 'Достапен',
        'thickness' => '2cm, 3cm',
        'finish' => 'Полиран, Матиран'
    ],
    
    // Kitchen Products
    [
        'id' => 'marble-kitchen-countertop',
        'name' => 'Мермерна кујнска работна плоча',
        'category' => 'kitchen',
        'description' => 'Елегантна мермерна работна плоча за кујна со висококвалитетна обработка.',
        'long_description' => 'Нашите мермерни кујнски работни плочи се изработени од најквалитетен мермер со прецизна обработка. Идеални за модерни кујни што бараат елеганција и функционалност.',
        'features' => ['Висока издржливост', 'Елегантен изглед', 'Лесно одржување', 'Отпорност на топлина'],
        'applications' => ['Кујнски работни плочи', 'Островни кујни', 'Бар шанкови'],
        'images' => ['kitchen/kitchen-marble-countertops.jpeg'],
        'main_image' => 'kitchen/kitchen-marble-countertops.jpeg',
        'availability' => 'Достапен',
        'thickness' => '2cm, 3cm',
        'finish' => 'Полиран, Матиран'
    ],
    [
        'id' => 'granite-kitchen-countertop',
        'name' => 'Гранитна кујнска работна плоча',
        'category' => 'kitchen',
        'description' => 'Трајна гранитна работна плоча за кујна со извонредна издржливост.',
        'long_description' => 'Гранитните кујнски работни плочи се познати по својата извонредна издржливост и отпорност на гребење. Совршени за активни кујни што бараат трајност.',
        'features' => ['Извонредна издржливост', 'Отпорност на гребење', 'Отпорност на топлина', 'Ниско одржување'],
        'applications' => ['Кујнски работни плочи', 'Островни кујни', 'Бар шанкови'],
        'images' => ['kitchen/granite-kitchen-1.jpg'],
        'main_image' => 'kitchen/granite-kitchen-1.jpg',
        'availability' => 'Достапен',
        'thickness' => '2cm, 3cm',
        'finish' => 'Полиран, Матиран'
    ],
    
    // Bathroom Products
    [
        'id' => 'marble-bathroom-vanity',
        'name' => 'Мермерна бања',
        'category' => 'bathroom',
        'description' => 'Луксузна мермерна бања со елегантен дизајн.',
        'long_description' => 'Нашите мермерни бањски шкафчиња комбинираат елеганција со функционалност. Изработени од висококвалитетен мермер со прецизна обработка.',
        'features' => ['Елегантен дизајн', 'Висока издржливост', 'Отпорност на влага', 'Лесно одржување'],
        'applications' => ['Бањски шкафчиња', 'Тоалетни шкафчиња', 'Бањски ракови'],
        'images' => ['bathroom/marble-bathroom-1.jpeg'],
        'main_image' => 'bathroom/marble-bathroom-1.jpeg',
        'availability' => 'Достапен',
        'thickness' => '2cm, 3cm',
        'finish' => 'Полиран, Матиран'
    ],
    [
        'id' => 'granite-bathroom-vanity',
        'name' => 'Гранитна бања',
        'category' => 'bathroom',
        'description' => 'Модерна гранитна бања со извонредна издржливост.',
        'long_description' => 'Гранитните бањски шкафчиња се познати по својата извонредна издржливост и отпорност на влага. Совршени за модерни бањи.',
        'features' => ['Извонредна издржливост', 'Отпорност на влага', 'Модерен дизајн', 'Ниско одржување'],
        'applications' => ['Бањски шкафчиња', 'Тоалетни шкафчиња', 'Бањски ракови'],
        'images' => ['bathroom/2-1698656075-1h2zB (1).jpg'],
        'main_image' => 'bathroom/2-1698656075-1h2zB (1).jpg',
        'availability' => 'Достапен',
        'thickness' => '2cm, 3cm',
        'finish' => 'Полиран, Матиран'
    ],
    
    // Floor Products
    [
        'id' => 'marble-floor-tiles',
        'name' => 'Мермерни подни плочи',
        'category' => 'floor',
        'description' => 'Елегантни мермерни подни плочи за луксузни ентериери.',
        'long_description' => 'Нашите мермерни подни плочи се изработени од најквалитетен мермер со прецизна обработка. Идеални за луксузни ентериери што бараат елеганција.',
        'features' => ['Елегантен изглед', 'Висока издржливост', 'Лесно одржување', 'Топлост'],
        'applications' => ['Подови', 'Скали', 'Фасади', 'Интериерни облоги'],
        'images' => ['marbel-floor/Marble-Floors-002.jpg', 'marbel-floor/marble-floor-tiles.webp'],
        'main_image' => 'marbel-floor/Marble-Floors-002.jpg',
        'availability' => 'Достапен',
        'thickness' => '1cm, 2cm',
        'finish' => 'Полиран, Матиран, Жбрусен'
    ],
    [
        'id' => 'granite-floor-tiles',
        'name' => 'Гранитни подни плочи',
        'category' => 'floor',
        'description' => 'Трајни гранитни подни плочи за интензивна употреба.',
        'long_description' => 'Гранитните подни плочи се познати по својата извонредна издржливост и отпорност на абење. Совршени за интензивна употреба во јавни и приватни простори.',
        'features' => ['Извонредна издржливост', 'Отпорност на абење', 'Ниско одржување', 'Трајност'],
        'applications' => ['Подови', 'Скали', 'Фасади', 'Надворешни облоги'],
        'images' => ['granit-floor/images (1).jpeg'],
        'main_image' => 'granit-floor/images (1).jpeg',
        'availability' => 'Достапен',
        'thickness' => '1cm, 2cm',
        'finish' => 'Полиран, Матиран, Жбрусен'
    ],
    
    // Sculpture Products
    [
        'id' => 'sculpture-marble-1',
        'name' => 'Класичен мермерен бист',
        'category' => 'sculpture-tombstones',
        'description' => 'Елегантен мермерен бист во класичен стил, изработен од најквалитетен мермер.',
        'long_description' => 'Нашите мермерни бистови се изработени од најквалитетен мермер со прецизна обработка. Идеални за декоративни цели и колекционерски предмети.',
        'features' => ['Класичен дизајн', 'Висока прецизност', 'Елегантен изглед', 'Трајност'],
        'applications' => ['Декорација', 'Колекционерски предмети', 'Споменици', 'Интериерни детали'],
        'images' => ['sculptures/sculpture (1).jpg'],
        'main_image' => 'sculptures/sculpture (1).jpg',
        'availability' => 'Достапен',
        'thickness' => 'Различни димензии',
        'finish' => 'Полиран, Матиран'
    ],
    [
        'id' => 'sculpture-granite-1',
        'name' => 'Апстрактна гранитна скулптура',
        'category' => 'sculpture-tombstones',
        'description' => 'Модерна апстрактна скулптура од гранит со уникатен дизајн.',
        'long_description' => 'Нашите гранитни апстрактни скулптури се изработени од најквалитетен гранит со модерен дизајн. Идеални за современ ентериер и екстериер.',
        'features' => ['Модерен дизајн', 'Висока издржливост', 'Уникатен изглед', 'Отпорност на временски влијанија'],
        'applications' => ['Ентериерна декорација', 'Екстериерна декорација', 'Градина', 'Јавни простори'],
        'images' => ['sculptures/sculpture (2).jpg'],
        'main_image' => 'sculptures/sculpture (2).jpg',
        'availability' => 'Достапен',
        'thickness' => 'Различни димензии',
        'finish' => 'Полиран, Матиран, Жбрусен'
    ],
    [
        'id' => 'sculpture-marble-2',
        'name' => 'Мермерна животинска скулптура',
        'category' => 'sculpture-tombstones',
        'description' => 'Детална мермерна скулптура на животни со реалистичен изглед.',
        'long_description' => 'Нашите мермерни животински скулптури се изработени со голема прецизност и внимание кон детали. Идеални за градини и декоративни цели.',
        'features' => ['Реалистичен дизајн', 'Детална обработка', 'Елегантен изглед', 'Трајност'],
        'applications' => ['Градинска декорација', 'Интериерна декорација', 'Колекционерски предмети'],
        'images' => ['sculptures/sculpture (3).jpg'],
        'main_image' => 'sculptures/sculpture (3).jpg',
        'availability' => 'Достапен',
        'thickness' => 'Различни димензии',
        'finish' => 'Полиран, Матиран'
    ],
    [
        'id' => 'sculpture-granite-2',
        'name' => 'Гранитна спомен скулптура',
        'category' => 'sculpture-tombstones',
        'description' => 'Трајна гранитна спомен скулптура за спомен цели.',
        'long_description' => 'Нашите гранитни спомен скулптури се изработени од најквалитетен гранит со фокус на трајност и елеганција. Идеални за спомен цели и меморијали.',
        'features' => ['Трајност', 'Елегантен дизајн', 'Отпорност на временски влијанија', 'Висока издржливост'],
        'applications' => ['Споменици', 'Меморијали', 'Гробишта', 'Спомен паркови'],
        'images' => ['tombstones/tombstones (1).jpg'],
        'main_image' => 'tombstones/tombstones (1).jpg',
        'availability' => 'Достапен',
        'thickness' => 'Различни димензии',
        'finish' => 'Полиран, Матиран'
    ],
    [
        'id' => 'sculpture-marble-3',
        'name' => 'Мермерна религиозна скулптура',
        'category' => 'sculpture-tombstones',
        'description' => 'Сакрална мермерна скулптура за религиозни цели.',
        'long_description' => 'Нашите мермерни религиозни скулптури се изработени со голема прецизност и почит кон традицијата. Идеални за цркви, манастири и приватни сакрални простори.',
        'features' => ['Сакрален дизајн', 'Висока прецизност', 'Традиционален стил', 'Трајност'],
        'applications' => ['Цркви', 'Манастири', 'Сакрални простори', 'Приватни капели'],
        'images' => ['sculptures/sculpture (10).jpg'],
        'main_image' => 'sculptures/sculpture (10).jpg',
        'availability' => 'Достапен',
        'thickness' => 'Различни димензии',
        'finish' => 'Полиран, Матиран'
    ],
    [
        'id' => 'sculpture-granite-3',
        'name' => 'Гранитна фонтана скулптура',
        'category' => 'sculpture-tombstones',
        'description' => 'Елегантна гранитна фонтана скулптура за градини и јавни простори.',
        'long_description' => 'Нашите гранитни фонтана скулптури комбинираат уметнички дизајн со функционалност. Идеални за градини, паркови и јавни простори.',
        'features' => ['Функционален дизајн', 'Отпорност на вода', 'Елегантен изглед', 'Трајност'],
        'applications' => ['Градини', 'Паркови', 'Јавни простори', 'Приватни дворови'],
        'images' => ['sculptures/sculpture (7).jpg'],
        'main_image' => 'sculptures/sculpture (7).jpg',
        'availability' => 'Достапен',
        'thickness' => 'Различни димензии',
        'finish' => 'Полиран, Матиран'
    ],
    [
        'id' => 'sculpture-marble-99',
        'name' => 'Прилагодена мермерна скулптура',
        'category' => 'sculpture-tombstones',
        'description' => 'Прилагодена мермерна скулптура според вашите спецификации.',
        'long_description' => 'Нашите прилагодени мермерни скулптури се изработуваат според вашите спецификации и дизајн. Работиме со клиентите за да создадеме уникатни уметнички дела.',
        'features' => ['Прилагоден дизајн', 'Уникатност', 'Висока прецизност', 'Професионална консултација'],
        'applications' => ['Приватни колекции', 'Корпоративни простори', 'Јавни нарачки', 'Специјални проекти'],
        'images' => ['sculptures/sculpture (12).jpg'],
        'main_image' => 'sculptures/sculpture (12).jpg',
        'availability' => 'По нарачка',
        'thickness' => 'Според спецификации',
        'finish' => 'Според спецификации'
    ],
    [
        'id' => 'sculpture-granite-4',
        'name' => 'Гранитна архитектонска скулптура',
        'category' => 'sculpture-tombstones',
        'description' => 'Монументална гранитна архитектонска скулптура за јавни простори.',
        'long_description' => 'Нашите гранитни архитектонски скулптури се дизајнирани за јавни простори и монументални проекти. Комбинираат уметнички дизајн со архитектонска функционалност.',
        'features' => ['Монументален дизајн', 'Висока издржливост', 'Архитектонска функционалност', 'Отпорност на временски влијанија'],
        'applications' => ['Јавни простори', 'Архитектонски проекти', 'Урбанистички решенија', 'Културни институции'],
        'images' => ['sculptures/sculpture (9).jpg'],
        'main_image' => 'sculptures/sculpture (9).jpg',
        'availability' => 'По нарачка',
        'thickness' => 'Различни димензии',
        'finish' => 'Полиран, Матиран, Жбрусен'
    ]]);

// Function to get product by ID
function getProductById($id) {
    global $products;
    foreach ($products as $product) {
        if ($product['id'] === $id) {
            return $product;
        }
    }
    return null;
}

// Transliterate Macedonian Cyrillic to Macedonian Latin (basic approximation)
function mkTransliterateToLatin($text) {
    $map = [
        'А'=>'A','а'=>'a','Б'=>'B','б'=>'b','В'=>'V','в'=>'v','Г'=>'G','г'=>'g','Д'=>'D','д'=>'d',
        'Ѓ'=>'Gj','ѓ'=>'gj','Е'=>'E','е'=>'e','Ж'=>'Zh','ж'=>'zh','З'=>'Z','з'=>'z','Ѕ'=>'Dz','ѕ'=>'dz',
        'И'=>'I','и'=>'i','Ј'=>'J','ј'=>'j','К'=>'K','к'=>'k','Л'=>'L','л'=>'l','Љ'=>'Lj','љ'=>'lj',
        'М'=>'M','м'=>'m','Н'=>'N','н'=>'n','Њ'=>'Nj','њ'=>'nj','О'=>'O','о'=>'o','П'=>'P','п'=>'p',
        'Р'=>'R','р'=>'r','С'=>'S','с'=>'s','Т'=>'T','т'=>'t','Ќ'=>'Kj','ќ'=>'kj','У'=>'U','у'=>'u',
        'Ф'=>'F','ф'=>'f','Х'=>'H','х'=>'h','Ц'=>'C','ц'=>'c','Ч'=>'Ch','ч'=>'ch','Џ'=>'Dj','џ'=>'dj',
        'Ш'=>'Sh','ш'=>'sh'
    ];
    return strtr($text, $map);
}

// Build a slug for a product using Macedonian Latin
function getProductSlug($product) {
    $baseName = isset($product['name']) ? $product['name'] : $product['id'];
    $latin = mkTransliterateToLatin($baseName);
    $latin = strtolower($latin);
    // Replace specific terms to be consistent
    $latin = str_replace(['мермер', 'granit', 'granite', 'marble'], ['mermer', 'granit', 'granit', 'mermer'], $latin);
    // Normalize
    $slug = preg_replace('/[^a-z0-9]+/i', '-', $latin);
    $slug = trim($slug, '-');
    // Ensure uniqueness by appending short id suffix
    if (!empty($product['id'])) {
        $suffix = substr(md5($product['id']), 0, 6);
        $slug .= '-' . $suffix;
    }
    return $slug;
}

// Resolve product by slug
function getProductBySlug($slug) {
    global $products;
    foreach ($products as $product) {
        if (getProductSlug($product) === $slug) {
            return $product;
        }
    }
    return null;
}

// Function to get products by category
function getProductsByCategory($category) {
    global $products;
    $filtered = [];
    foreach ($products as $product) {
        if ($product['category'] === $category) {
            $filtered[] = $product;
        }
    }
    return $filtered;
}

// Function to get all products
function getAllProducts() {
    global $products;
    return $products;
}

// Function to get all categories
function getAllCategories() {
    global $products;
    $categories = [];
    foreach ($products as $product) {
        if (!in_array($product['category'], $categories)) {
            $categories[] = $product['category'];
        }
    }
    return $categories;
}
?> 
